package com.example.homework;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
    private DrawingView drawingView;
    private Button clearButton;
    private Button undoButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 查找视图
        drawingView = findViewById(R.id.drawing_view);
        clearButton = findViewById(R.id.clear_button);
        undoButton = findViewById(R.id.undo_button);

        // 设置清空按钮的点击事件监听器
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawingView.clear();
            }
        });

        // 设置撤销按钮的点击事件监听器
        undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawingView.undo();
            }
        });
    }
}
