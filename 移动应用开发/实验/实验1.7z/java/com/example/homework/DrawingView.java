package com.example.homework;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class DrawingView extends View {
    private Paint paint;
    private Path path;
    private List<Path> paths;
    private List<Path> undonePaths;

    public DrawingView(Context context, AttributeSet attrs) {
        super(context, attrs);

        // 初始化画笔
        paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5);

        // 初始化路径列表
        paths = new ArrayList<>();
        undonePaths = new ArrayList<>();

        // 初始化当前路径
        path = new Path();
        paths.add(path);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // 绘制所有路径
        for (Path p : paths) {
            canvas.drawPath(p, paint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                // 按下时开始新路径
                path = new Path();
                path.moveTo(x, y);
                paths.add(path);
                break;
            case MotionEvent.ACTION_MOVE:
                // 移动时绘制当前路径
                path.lineTo(x, y);
                break;
            case MotionEvent.ACTION_UP:
                // 抬起时重绘
                invalidate();
                break;
        }

        // 返回true表示处理了触摸事件
        return true;
    }

    // 清除画板
    public void clear() {
        paths.clear();
        invalidated();
    }

    // 撤回操作
    public void undo() {
        if (paths.size() > 0) {
            undonePaths.add(paths.remove(paths.size() - 1));
            invalidated();
        }
    }

    // 重新绘制视图
    private void invalidated() {
        invalidate();
    }
}
