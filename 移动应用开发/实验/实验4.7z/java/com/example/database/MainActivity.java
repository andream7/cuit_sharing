package com.example.database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText idEditText, usernameEditText, telEditText, addressEditText, emailEditText;
    private Button openDbButton, nextButton, prevButton, addButton, updateButton, deleteButton;
    private DBHelper dbHelper;
    private SQLiteDatabase database;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        idEditText = findViewById(R.id.id);
        usernameEditText = findViewById(R.id.username);
        telEditText = findViewById(R.id.tel);
        addressEditText = findViewById(R.id.address);
        emailEditText = findViewById(R.id.email);

        openDbButton = findViewById(R.id.open_db_button);
        nextButton = findViewById(R.id.next_button);
        prevButton = findViewById(R.id.prev_button);
        addButton = findViewById(R.id.add_button);
        updateButton = findViewById(R.id.update_button);
        deleteButton = findViewById(R.id.delete_button);

        dbHelper = new DBHelper(this);

        openDbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                database = dbHelper.getWritableDatabase();
                cursor = database.query("Users", null, null, null, null, null, null);
                if (cursor.moveToFirst()) {
                    displayRecord();
                }
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cursor != null && !cursor.isAfterLast() && cursor.moveToNext()) {
                    displayRecord();
                }
            }
        });

        prevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cursor != null && !cursor.isBeforeFirst() && cursor.moveToPrevious()) {
                    displayRecord();
                }
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String tel = telEditText.getText().toString();
                String address = addressEditText.getText().toString();
                String email = emailEditText.getText().toString();

                database.execSQL("INSERT INTO Users (username, usertel, useraddress, useremail) VALUES (?, ?, ?, ?)",
                        new Object[]{username, tel, address, email});
                refreshCursor();
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = idEditText.getText().toString();
                String username = usernameEditText.getText().toString();
                String tel = telEditText.getText().toString();
                String address = addressEditText.getText().toString();
                String email = emailEditText.getText().toString();

                database.execSQL("UPDATE Users SET username=?, usertel=?, useraddress=?, useremail=? WHERE _id=?",
                        new Object[]{username, tel, address, email, id});
                refreshCursor();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = idEditText.getText().toString();
                database.execSQL("DELETE FROM Users WHERE _id=?", new Object[]{id});
                refreshCursor();
            }
        });
    }

    private void refreshCursor() {
        cursor = database.query("Users", null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            displayRecord();
        }
    }

    private void displayRecord() {
        String id = cursor.getString(cursor.getColumnIndexOrThrow("_id"));
        String username = cursor.getString(cursor.getColumnIndexOrThrow("username"));
        String tel = cursor.getString(cursor.getColumnIndexOrThrow("usertel"));
        String address = cursor.getString(cursor.getColumnIndexOrThrow("useraddress"));
        String email = cursor.getString(cursor.getColumnIndexOrThrow("useremail"));

        idEditText.setText(id);
        usernameEditText.setText(username);
        telEditText.setText(tel);
        addressEditText.setText(address);
        emailEditText.setText(email);
    }
}
