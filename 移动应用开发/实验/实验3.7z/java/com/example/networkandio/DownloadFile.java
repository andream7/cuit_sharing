package com.example.networkandio;

import android.os.FileUtils;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadFile {
    public static void download(final String path, final String fileName) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(path);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setReadTimeout(5000);
                    con.setConnectTimeout(5000);
                    con.setRequestProperty("Charset", "UTF-8");
                    con.setRequestMethod("GET");

                    if (con.getResponseCode() == 200) {
                        InputStream is = con.getInputStream();
                        FileUtiler fileUtils = new FileUtiler();
                        System.out.println(fileUtils.createFile(fileName));
                        FileOutputStream fos = new FileOutputStream(fileUtils.createFile(fileName));

                        byte[] buf = new byte[1024];
                        int ch;
                        while ((ch = is.read(buf)) != -1) {
                            fos.write(buf, 0, ch);
                        }

                        if (fos != null) {
                            fos.flush();
                            fos.close();
                        }

                        if (is != null) {
                            is.close();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
