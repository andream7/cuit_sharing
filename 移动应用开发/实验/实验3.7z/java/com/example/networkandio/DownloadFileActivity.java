package com.example.networkandio;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class DownloadFileActivity extends AppCompatActivity {
    private EditText urlEditText, fileNameEditText;
    private Button downloadButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_file);

        urlEditText = findViewById(R.id.et1);
        fileNameEditText = findViewById(R.id.et2);
        downloadButton = findViewById(R.id.btn1);

        downloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = urlEditText.getText().toString();
                String fileName = fileNameEditText.getText().toString();

                if (!url.isEmpty() && !fileName.isEmpty()) {
                    DownloadFile.download(url, fileName);
                    Toast.makeText(DownloadFileActivity.this, "Download started...", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(DownloadFileActivity.this, "Please fill in both URL and File Name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}