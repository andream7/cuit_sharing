package com.example.networkandio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText;
    private CheckBox rememberCheckBox;
    private Button loginButton;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        rememberCheckBox = findViewById(R.id.remember);
        loginButton = findViewById(R.id.login_button);

        sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        loadPreferences();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (rememberCheckBox.isChecked()) {
                    savePreferences(username, password);
                }

                // Simulate a login and navigate to DownloadFileActivity
                Intent intent = new Intent(MainActivity.this, DownloadFileActivity.class);
                startActivity(intent);
            }
        });
    }

    private void savePreferences(String username, String password) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("Username", username);
        editor.putString("Password", password);
        editor.putBoolean("Remember", true);
        editor.apply();
    }

    private void loadPreferences() {
        boolean remember = sharedPreferences.getBoolean("Remember", false);
        if (remember) {
            usernameEditText.setText(sharedPreferences.getString("Username", ""));
            passwordEditText.setText(sharedPreferences.getString("Password", ""));
            rememberCheckBox.setChecked(true);
        }
    }
}