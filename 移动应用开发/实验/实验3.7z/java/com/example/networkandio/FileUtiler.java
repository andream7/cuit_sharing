package com.example.networkandio;

import android.os.Environment;
import java.io.File;

public class FileUtiler {
    private final String rootPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Download/";

    public FileUtiler() {
        File rootDir = new File(rootPath);
        if (!rootDir.exists()) {
            rootDir.mkdirs();
        }
    }

    public File createFile(String fileName) {
        return new File(rootPath + fileName);
    }
}