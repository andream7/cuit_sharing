package com.example.homework2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private EditText editTextInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Button buttonSendResult = findViewById(R.id.button_send_result);
        editTextInput = findViewById(R.id.editText_input);

        buttonSendResult.setOnClickListener(v -> {
            String inputMessage = editTextInput.getText().toString();
            Intent resultIntent = new Intent();
            resultIntent.putExtra("resultMessage", inputMessage);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}