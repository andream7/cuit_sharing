package com.yourpackage;

import java.io.File;

public class TestFileOperation {
    public static void main(String[] args) {
        // 获取 FileOperation 的单例实例
        FileOperation fileOp1 = FileOperation.getInstance();
        FileOperation fileOp2 = FileOperation.getInstance();

        // 验证单例模式（两个实例应该是同一个）
        System.out.println("fileOp1 和 fileOp2 是同一个实例吗？ " + (fileOp1 == fileOp2));

        // 定义示例文件路径（请根据实际情况修改路径）
        File file = new File("src/com/yourpackage/example.txt");

        // 显示文件信息
        System.out.println("文件名: " + fileOp1.getFileName(file));
        System.out.println("文件路径: " + fileOp1.getFilePath(file));
        System.out.println("文件大小: " + fileOp1.getFileSize(file) + " 字节");

        // 读取文件内容
        String content = fileOp1.readFileContent(file);
        System.out.println("文件内容:\n" + content);

        // 复制文件到新的位置
        // 复制后的文件名为 copy_example.txt
        File copyDest = new File("copy_example.txt");
        boolean copyResult = fileOp1.copyFile(file, copyDest);
        System.out.println("复制文件 " + (copyResult ? "成功" : "失败"));

        // 移动文件到新的位置
        // 移动后的文件名为 moved_example.txt
        File moveDest = new File("moved_example.txt");
        boolean moveResult = fileOp1.moveFile(copyDest, moveDest);
        System.out.println("移动文件 " + (moveResult ? "成功" : "失败"));
    }
}
