package com.yourpackage;

import java.io.*;
import java.nio.file.*;

public class FileOperation {
    // volatile 关键字确保多线程环境下的可见性
    private static volatile FileOperation instance = null;

    // 私有构造方法，防止外部实例化
    private FileOperation() {
        // 初始化操作（如果有）
    }

    // 公共的获取实例的方法，使用双重检查锁定
    public static FileOperation getInstance() {
        if (instance == null) { // 第一次检查
            synchronized (FileOperation.class) {
                if (instance == null) { // 第二次检查
                    instance = new FileOperation();
                }
            }
        }
        return instance;
    }

    // 显示文件名
    public String getFileName(File file) {
        return file.getName();
    }

    // 显示文件路径
    public String getFilePath(File file) {
        try {
            return file.getCanonicalPath();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 显示文件大小（字节）
    public long getFileSize(File file) {
        return file.length();
    }

    // 读取文件内容
    public String readFileContent(File file) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line).append(System.lineSeparator());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
    }

    // 复制文件到目标路径
    public boolean copyFile(File source, File dest) {
        try {
            Files.copy(source.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // 移动文件到目标路径
    public boolean moveFile(File source, File dest) {
        try {
            Files.move(source.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
