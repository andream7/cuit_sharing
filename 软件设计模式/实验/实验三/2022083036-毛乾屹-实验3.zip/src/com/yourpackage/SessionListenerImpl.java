package com.yourpackage;

/**
 * SessionListenerImpl 类，作为具体的 Observer 实现。
 */
public class SessionListenerImpl extends SessionListener {

    /**
     * 当 Session 设置属性时调用的方法。
     *
     * @param session 当前 Session 对象
     * @param key     属性名
     * @param value   属性值
     */
    @Override
    public void onSetSessionAttribute(Session session, String key, Object value) {
        if (session instanceof HttpSession) {
            HttpSession httpSession = (HttpSession) session;
            System.out.println("Session ID: " + httpSession.getSessionId() + " - 设置属性: " + key + " = " + value);
        } else {
            System.out.println("设置属性: " + key + " = " + value);
        }
    }

    /**
     * 当 Session 移除属性时调用的方法。
     *
     * @param session 当前 Session 对象
     * @param key     属性名
     * @param value   属性值
     */
    @Override
    public void onRemoveSessionAttribute(Session session, String key, Object value) {
        if (session instanceof HttpSession) {
            HttpSession httpSession = (HttpSession) session;
            System.out.println("Session ID: " + httpSession.getSessionId() + " - 移除属性: " + key + " = " + value);
        } else {
            System.out.println("移除属性: " + key + " = " + value);
        }
    }
}
