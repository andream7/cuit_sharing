package com.yourpackage;

/**
 * SessionListener 抽象类，作为观察者模式中的 Observer。
 */
public abstract class SessionListener {
    /**
     * 当 Session 设置属性时调用的方法。
     *
     * @param session 当前 Session 对象
     * @param key     属性名
     * @param value   属性值
     */
    public abstract void onSetSessionAttribute(Session session, String key, Object value);

    /**
     * 当 Session 移除属性时调用的方法。
     *
     * @param session 当前 Session 对象
     * @param key     属性名
     * @param value   属性值
     */
    public abstract void onRemoveSessionAttribute(Session session, String key, Object value);
}
