package com.yourpackage;

/**
 * HttpSession 类，作为具体的 Subject 实现。
 */
public class HttpSession extends Session {
    private String sessionId;

    /**
     * 构造方法，初始化 Session ID。
     *
     * @param sessionId 会话ID
     */
    public HttpSession(String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * 获取 Session ID。
     *
     * @return Session ID
     */
    public String getSessionId() {
        return sessionId;
    }
}
