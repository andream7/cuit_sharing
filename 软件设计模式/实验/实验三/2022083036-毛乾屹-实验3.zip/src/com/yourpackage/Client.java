package com.yourpackage;

/**
 * Client 类，用于测试观察者模式的实现。
 */
public class Client {
    public static void main(String[] args) {
        // 创建 HttpSession 对象
        HttpSession session = new HttpSession("ABC123");

        // 创建 SessionListenerImpl 对象
        SessionListener listener = new SessionListenerImpl();

        // 注册观察者
        session.addSessionListener(listener);

        // 设置 Session 属性
        session.setAttribute("username", "john_doe");
        session.setAttribute("isLoggedIn", true);

        // 移除 Session 属性
        session.removeAttribute("isLoggedIn");
    }
}
