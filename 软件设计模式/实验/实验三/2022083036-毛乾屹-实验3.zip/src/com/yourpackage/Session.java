package com.yourpackage;

import java.util.ArrayList;
import java.util.List;

/**
 * Session 抽象类，作为观察者模式中的 Subject。
 */
public abstract class Session {
    // 存储 Session 属性
    protected java.util.Map<String, Object> attributes = new java.util.HashMap<>();

    // 存储观察者列表
    private List<SessionListener> listeners = new ArrayList<>();

    /**
     * 注册观察者。
     *
     * @param listener 需要注册的 SessionListener
     */
    public void addSessionListener(SessionListener listener) {
        listeners.add(listener);
    }

    /**
     * 注销观察者。
     *
     * @param listener 需要注销的 SessionListener
     */
    public void removeSessionListener(SessionListener listener) {
        listeners.remove(listener);
    }

    /**
     * 设置 Session 属性，并通知观察者。
     *
     * @param key   属性名
     * @param value 属性值
     */
    public void setAttribute(String key, Object value) {
        attributes.put(key, value);
        notifySetAttribute(key, value);
    }

    /**
     * 移除 Session 属性，并通知观察者。
     *
     * @param key 属性名
     */
    public void removeAttribute(String key) {
        Object value = attributes.remove(key);
        notifyRemoveAttribute(key, value);
    }

    /**
     * 通知所有观察者设置属性事件。
     *
     * @param key   属性名
     * @param value 属性值
     */
    protected void notifySetAttribute(String key, Object value) {
        for (SessionListener listener : listeners) {
            listener.onSetSessionAttribute(this, key, value);
        }
    }

    /**
     * 通知所有观察者移除属性事件。
     *
     * @param key   属性名
     * @param value 属性值
     */
    protected void notifyRemoveAttribute(String key, Object value) {
        for (SessionListener listener : listeners) {
            listener.onRemoveSessionAttribute(this, key, value);
        }
    }
}
