package com.yourpackage;

/**
 * 测试类，验证适配器模式是否正确地将 WAV 格式的音频播放器适配到应用程序中。
 */
public class TestAudioPlayer {
    public static void main(String[] args) {
        // 创建 MP3Player 对象，直接使用 AudioPlayer 接口
        AudioPlayer mp3Player = new MP3Player();
        mp3Player.playAudio("song.mp3");

        // 创建 WAVAdapter 对象，通过适配器使用 WAVPlayer
        AudioPlayer wavAdapter = new WAVAdapter();
        wavAdapter.playAudio("song.wav");

        // 也可以使用适配器模式扩展更多格式的音频播放器
        // 例如，如果需要支持 FLAC 格式，可以创建相应的 Adapter 类
    }
}
