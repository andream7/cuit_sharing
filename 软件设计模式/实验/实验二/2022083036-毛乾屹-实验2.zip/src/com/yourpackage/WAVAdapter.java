package com.yourpackage;

/**
 * WAV 格式音频播放器的适配器类，实现了 AudioPlayer 接口。
 */
public class WAVAdapter implements AudioPlayer {

    private WAVPlayer wavPlayer;

    /**
     * 构造方法，初始化 WAVPlayer 对象。
     */
    public WAVAdapter() {
        this.wavPlayer = new WAVPlayer();
    }

    /**
     * 通过适配器调用 WAVPlayer 的播放方法。
     *
     * @param fileName 音频文件名。
     */
    @Override
    public void playAudio(String fileName) {
        wavPlayer.playWAV(fileName);
    }
}
