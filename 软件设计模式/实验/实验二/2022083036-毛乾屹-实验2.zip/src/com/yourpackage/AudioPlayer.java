package com.yourpackage;

/**
 * 音频播放器接口，定义播放音频的方法。
 */
public interface AudioPlayer {
    /**
     * 播放音频文件。
     *
     * @param fileName 音频文件名。
     */
    void playAudio(String fileName);
}
