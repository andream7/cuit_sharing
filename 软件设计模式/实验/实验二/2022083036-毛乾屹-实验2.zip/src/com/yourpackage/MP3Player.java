package com.yourpackage;

/**
 * MP3 格式音频播放器，实现了 AudioPlayer 接口。
 */
public class MP3Player implements AudioPlayer {

    /**
     * 播放 MP3 音频文件。
     *
     * @param fileName 音频文件名。
     */
    @Override
    public void playAudio(String fileName) {
        System.out.println("Playing MP3 file: " + fileName);
    }
}
