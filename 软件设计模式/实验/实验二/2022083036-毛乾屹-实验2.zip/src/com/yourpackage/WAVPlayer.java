package com.yourpackage;

/**
 * WAV 格式音频播放器，不实现 AudioPlayer 接口。
 */
public class WAVPlayer {

    /**
     * 播放 WAV 音频文件。
     *
     * @param fileName 音频文件名。
     */
    public void playWAV(String fileName) {
        System.out.println("Playing WAV file: " + fileName);
    }
}
